#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

// Structure
struct Machine {
    string itemID;
    string type;
    double powerWatts;
    double maxHeat;
    int serviceLimit;
    double totalRunTime;
    double todayHours;
    double todayTemp;
};

// Global variables
const int LIMIT = 30;
Machine shopList[LIMIT];
int totalItems = 0;

// Function prototypes
void addNewItem();
void updateDailyData();
void checkStatus();
void calcElectricity();

int main() {

    int userSelect;

    // Dummy data  for testing
    shopList[0] = {"EQ01","Drill",1200,80,100,40,3,60};
    shopList[1] = {"EQ02","Welder",2000,100,150,70,5,75};
    shopList[2] = {"EQ03","Cutter",900,70,80,20,2,50};
    totalItems = 3;

    // Menu loop
    do {

        cout << "\n--- SWESMS SYSTEM MENU ---" << endl;
        cout << "1. Add New Equipment" << endl;
        cout << "2. Update Today's Usage" << endl;
        cout << "3. View Safety Status/Alerts" << endl;
        cout << "4. View Energy & Cost Report" << endl;
        cout << "5. Exit Program" << endl;
        cout << "Enter choice (1-5): ";

        cin >> userSelect;

        // Prevent crash (Ai)
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input! Please enter a number between 1-5." << endl;
            continue;
        }

        if (userSelect == 1) {
            addNewItem();
        }
        else if (userSelect == 2) {
            updateDailyData();
        }
        else if (userSelect == 3) {
            checkStatus();
        }
        else if (userSelect == 4) {
            calcElectricity();
        }
        else if (userSelect == 5) {
            cout << "Closing system. Goodbye!" << endl;
        }
        else {
            cout << "Invalid choice. Please select 1 - 5." << endl;
        }

    } while (userSelect != 5);

    return 0;
}

// Add new equipment
void addNewItem() {

    if (totalItems < LIMIT) {

        cout << "\n[Registration Form]" << endl;

        cout << "Equipment ID: ";
        cin >> shopList[totalItems].itemID;

        cout << "Category: ";
        cin >> shopList[totalItems].type;

        cout << "Power (Watts): ";
        cin >> shopList[totalItems].powerWatts;

        cout << "Max Temperature Limit (Celsius): ";
        cin >> shopList[totalItems].maxHeat;

        cout << "Service Interval (hours): ";
        cin >> shopList[totalItems].serviceLimit;

        shopList[totalItems].totalRunTime = 0;
        shopList[totalItems].todayHours = 0;
        shopList[totalItems].todayTemp = 0;

        totalItems++;

        cout << "Success: Equipment registered." << endl;
    }
    else {
        cout << "Error: Workshop capacity reached." << endl;
    }
}

// Update daily data
void updateDailyData() {

    string target;

    cout << "\nEnter Item ID to update: ";
    cin >> target;

    int index = -1;

    for (int i = 0; i < totalItems; i++) {
        if (shopList[i].itemID == target) {
            index = i;
            break;
        }
    }

    if (index != -1) {

        double h;

        // Validation (0 - 24 allowed)
        do {

            cout << "Hours used today (0-24): ";
            cin >> h;

            if (cin.fail()) {
                cin.clear();
                cin.ignore(1000, '\n');
                cout << "Invalid input! Enter numbers only." << endl;
                h = -1;
            }

            else if (h < 0 || h > 24) {
                cout << "Error: Hours must be between 0 and 24." << endl;
            }

        } while (h < 0 || h > 24);

        shopList[index].todayHours = h;

        cout << "Current temperature (Celsius): ";
        cin >> shopList[index].todayTemp;

        shopList[index].totalRunTime += h;

        cout << "Data updated for " << target << endl;
    }
    else {
        cout << "ID not found in system." << endl;
    }
}

// Check machine status
void checkStatus() {

    cout << "\nID\t\tSTATUS\t\tALERTS" << endl;
    cout << "--------------------------------------------" << endl;

    for (int i = 0; i < totalItems; i++) {

        string stat;
        string msg = "-";

        if (shopList[i].todayTemp > shopList[i].maxHeat) {
            stat = "CRITICAL";
            msg = "OVERHEAT!";
        }

        else if (shopList[i].todayTemp >= (0.9 * shopList[i].maxHeat)) {
            stat = "WARNING";
            msg = "NEAR-OVERHEAT";
        }

        else {
            stat = "NORMAL";
        }

        if (shopList[i].totalRunTime >= shopList[i].serviceLimit) {
            msg += " (MAINT DUE)";
        }

        cout << shopList[i].itemID << "\t\t" << stat << "\t\t" << msg << endl;
    }
}

// Electricity calculation
void calcElectricity() {

    double grandTotalKWh = 0;

    for (int i = 0; i < totalItems; i++) {

        double itemKWh = (shopList[i].powerWatts / 1000.0) * shopList[i].todayHours;

        grandTotalKWh += itemKWh;
    }

    double finalCost = grandTotalKWh * 0.50;

    cout << "\n--- DAILY ENERGY REPORT ---" << endl;

    cout << fixed << setprecision(2);

    cout << "Total Energy: " << grandTotalKWh << " kWh" << endl;

    if (grandTotalKWh > 8) {

        double extra = finalCost * 0.20;

        finalCost += extra;

        cout << "Peak Surcharge (20%) added: RM " << extra << endl;
    }

    cout << "Final Total Cost: RM " << finalCost << endl;
}
